const Discord = require('discord.js');

const client = new Discord.Client({ partials: ["MESSAGE", "CHANNEL", "REACTION"]});
const fs = require('fs')


client.commands = new Discord.Collection();
client.events = new Discord.Collection();

['command_handler', 'event_handler'].forEach(handler =>{
  require(`./handlers/${handler}`)(client, Discord);
});



client.login('ODg5NzI4MTQ1Mzc5NDMwNDUw.YUld6A.vjy_jqVQA4Ahxh4LV1FWRh3iY7s');